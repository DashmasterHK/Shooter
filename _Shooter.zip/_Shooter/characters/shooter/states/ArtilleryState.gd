extends CharacterState

export var _c_CustomBang = 0
export(PackedScene) var BangProjectile
export var projPosX = 0
export var projPosY = 0

func _frame_6():
	var projectile = host.spawn_object(BangProjectile, projPosX, projPosY)
	projectile.set_facing(host.get_facing_int())
	host.play_sound("PistolShot")
