extends CharacterState

export var _c_CustomBang = 0
export(PackedScene) var BangProjectile
export var projPosX = 0
export var projPosY = 0

func _frame_8():
	host.spawn_object(BangProjectile, projPosX, projPosY)
