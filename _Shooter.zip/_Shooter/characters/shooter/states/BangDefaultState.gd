extends ObjectState

var hit_something = false

func _tick():
	if not hit_something:
		host.move_directly(60*host.get_facing_int(), 0)
		
	var pos = host.get_pos()
	if pos.x < -host.stage_width or pos.x > host.stage_width:
		hit_something = true
		host.disable()
	

func _on_hit_something(obj, hitbox):
	._on_hit_something(obj,hitbox)
	hit_something = true
	host.disable()
	
