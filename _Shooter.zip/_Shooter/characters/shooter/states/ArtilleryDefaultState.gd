extends DefaultFireball


	
